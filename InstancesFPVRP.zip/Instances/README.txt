Description:

MainSet: 

Contains instances used to test the matheuristic (the value of |K| was recalculated as it is explained in the paper/thesis). PVRP instances remain the same as in the literature.

TrainingSet: 

Contains instances generated using a uniform distribution u[0,1] for customers coordinates (not clustered). This set is used for the assesment of parameters of the matheuristic (applied only for the second revision of the paper).


We used the same format of benckmark instances (http://neo.lcc.uma.es/vrp/vrp-instances/description-for-files-of-cordeaus-instances/). For the FPVRP, we use only the necessary fields to solve the problem.
***************************************************
The format of data files is as follows:

Data files
The first line contains the following information:

type m n t

type: (optional for the FPVRP, use any value) 
m: number of vehicles (mandatory)
n: number of customers (mandatory)
t: number of days (PVRP), depots (MDVRP) or vehicle types (SDVRP)  -> (number of days for the FPVRP)
The next t lines contain, for each day (or depot or vehicle type), the following information:

D Q   

D: maximum duration of a route (optional for the FPVRP, use 0)
Q: maximum load of a vehicle	(mandatory for the FPVRP, use the value of vehicle capacity)

The next lines contain, for each customer, the following information:

i x y d q f a list

i: customer number	(The FPVRP uses the order of the list to assign an ID, first depot, then customers)
x: x coordinate		(mandatory)
y: y coordinate		(mandatory)
d: service duration	(any value)
q: demand			(mandatory)
f: frequency of visit	(mandatory)
a: number of possible visit combinations	(mandatory)			
list: list of all possible visit combinations	(mandatory)
